#!/bin/sh
echo pwned; rm -rf /tmp/whatever
